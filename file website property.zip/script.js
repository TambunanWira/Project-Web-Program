document.addEventListener('DOMContentLoaded', function() {
    const simulateButton = document.getElementById('simulateButton');
    simulateButton.addEventListener('click', function() {
        alert('Simulasi alur transaksi berjalan sesuai flowchart.\n\n1. Login / Daftar\n2. Pilih properti\n3. Hubungi agen\n4. Diskusi harga\n5. Pembayaran\n6. Upload bukti\n7. Verifikasi admin\n8. Transaksi berhasil.\n\nAdmin:\n1. Login admin\n2. Verifikasi pembayaran\n3. Update status\n4. Kirim notifikasi\n5. Proses selesai.');
    });
});